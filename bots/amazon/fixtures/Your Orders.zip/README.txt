Invented sample export for tests.
